import React from "react";
import HOME from "../images/VOTE.jpg"
function Home() {
    return (
        <div>
            <center>
            <img src={HOME} alt="HOME" style={{width:'97vw',height:"100vh",objectFit:"cover"}} /></center>
        </div>
    );
}
export default Home;