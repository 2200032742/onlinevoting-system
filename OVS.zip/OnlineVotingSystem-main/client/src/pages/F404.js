import React from "react";
import "../css/F404.css";

function F404() {
    return (
        <div className="error-container">
            <center>
                <h1>Page Not Found 404</h1>
            </center>
        </div>
    );
}

export default F404;
